python -m SimpleHTTPServer

